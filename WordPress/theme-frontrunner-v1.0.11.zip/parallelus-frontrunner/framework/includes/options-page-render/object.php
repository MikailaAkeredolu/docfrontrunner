<?php

class Generic_Settings_Object extends Runway_Object {

	function init( $settings ) {

		/* nothing */

	}

}

?>
