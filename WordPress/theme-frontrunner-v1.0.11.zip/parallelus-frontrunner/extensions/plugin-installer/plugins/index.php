<?php
/**
 * Put plugins inside the /plugin-installer/plugins directory.
 * Don't do anything with this file. It's just a placeholder.
 */