<?php
/*
    Extension Name: Bootstrap Navigation
    Version: 1.0
    Description: Custom navigation walker adds Bootstrap specific structure to WordPress navigation menus.
*/


// Include the custom nav walker class
require 'wp-bootstrap-navwalker.php';
