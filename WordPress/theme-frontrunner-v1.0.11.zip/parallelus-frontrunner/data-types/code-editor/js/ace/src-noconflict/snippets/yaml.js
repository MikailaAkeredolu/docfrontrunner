ace.define('ace/snippets/yaml', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "yaml";

});
