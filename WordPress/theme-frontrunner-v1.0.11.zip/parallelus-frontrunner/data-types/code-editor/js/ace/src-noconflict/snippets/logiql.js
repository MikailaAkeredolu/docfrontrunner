ace.define('ace/snippets/logiql', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "logiql";

});
