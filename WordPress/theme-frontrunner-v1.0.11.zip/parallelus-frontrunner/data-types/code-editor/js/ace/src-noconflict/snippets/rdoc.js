ace.define('ace/snippets/rdoc', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "rdoc";

});
